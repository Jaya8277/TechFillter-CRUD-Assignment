<script setup></script>

<template>
  <h1>Page Not Found</h1>
</template>

<style scoped></style>
